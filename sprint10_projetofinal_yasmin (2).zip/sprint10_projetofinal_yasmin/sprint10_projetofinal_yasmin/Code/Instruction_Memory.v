module Instruction_Memory (input [31:0] A,
output reg [31:0] RD);

always @(*)
begin

	case(A)
	32'h00 : RD <= 32'h00700293;
	32'h04 : RD <= 32'h00c000ef;
	32'h08 : RD <= 32'h0082e193;
	32'h0c : RD <= 32'h00c000ef;
	32'h10 : RD <= 32'h0012f113;
	32'h14 : RD <= 32'h00008067;
	32'h18 : RD <= 32'h0022d233;

	endcase

end

/*addi x5, x0, 7      # x5 = 7
jal x1, 12          # x1 = 0x08, PC salta para 0x10
andi x2, x5, 1      # x2 = x5 & 1 (pegar o bit menos significativo)
jalr x0, 0(x1)      # PC salta para o que está em x1 (0x08)
xor x3, x5, x1      # x3 = x5 XOR x1 (7 XOR 8 = 15)
jal x1, 12          # x1 = 0x10, PC salta para 0x18
srl x4, x5, x2      # x4 = x5 >> x2 (7 >> 1 = 3)*/



endmodule 


