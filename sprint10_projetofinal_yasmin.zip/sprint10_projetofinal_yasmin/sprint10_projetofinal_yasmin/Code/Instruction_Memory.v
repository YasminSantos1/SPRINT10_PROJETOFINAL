module Instruction_Memory (input [31:0] A,
output reg [31:0] RD);

always @(*)
begin

	case(A)
	32'h00 : RD <= 32'h00700293;
	32'h04 : RD <= 32'h00c000ef;
	32'h08 : RD <= 32'h0082e193;
	32'h0c : RD <= 32'h00c000ef;
	32'h10 : RD <= 32'h0012f113;
	32'h14 : RD <= 32'h00008067;
	32'h18 : RD <= 32'h0022d233;

	endcase

end



endmodule 


