module Program_Counter(input clk,
input rst,
input[31:0] PCin,
output reg [31:0] PC);

always @ (posedge clk or negedge rst)
begin
	if(!rst)
	PC <=0;
	else
	PC <= PCin;
	

end

endmodule


