module parallel_in
(input [31:0] Data_in,
input [31:0] Address, MemData,
output reg [31:0] RegData);

always @ (*)
begin
	if(Address == 	32'hFF)
	RegData <= Data_in;
	else
	RegData <= MemData;
end	
		
		
endmodule	
	